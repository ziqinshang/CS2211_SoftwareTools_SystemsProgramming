/* CS2211a 2020 */
/* Assignment 04 */
/* ziqin shang */
/* 250890594 */
/* zshang3 */
/* NOV 14 2020 */
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#define MAX 100
//char *usrinput(){
//    char *input;
//    size_t bufsize = 100;
//    size_t characters;
//    input = (char *)malloc(bufsize * sizeof(char));
//    printf("Enter a string: ");
//    characters = getline(&input,&bufsize,stdin);
////    printf("%zu characters were read.\n",characters);
////    printf("You typed: '%s'\n",input);
//    return input;
//}

