#include <stdio.h>
int main(){
printf("HelloWorld!");
return 0;
}

