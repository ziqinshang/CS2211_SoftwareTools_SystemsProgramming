/* CS2211a 2020 */
/* Lab 09 */
/* ziqin shang */
/* 250890594 */
/* zshang3*/
/*Nov 23 2020 */
#include "headers.h"

// A utility function to create a new BST node
struct node *newNode(int item, int pos)
{
	struct node *temp = (struct node *)malloc(sizeof(struct node));
	temp->data = item;
	temp->nodePosition = pos;
	temp->left = temp->right = NULL;
	return temp;
}

/* A utility function to insert a new node with given data in BST */
struct node* insertLeaf(struct node* node, int data, int pos)
{
	/* If the tree is empty, return a new node */
	if (node == NULL) return newNode(data, pos);

    if (data < node->data)
    node->left = insertLeaf(node->left, data,pos);
    else
    node->right = insertLeaf(node->right, data,pos);

	/* return the (unchanged) node pointer */
	return node;
}
