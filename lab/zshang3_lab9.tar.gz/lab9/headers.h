/* CS2211a 2020 */
/* Lab 09 */
/* ziqin shang */
/* 250890594 */
/* zshang3*/
/*Nov 23 2020 */
#ifndef HEADERS_H_INCLUDED
#define HEADERS_H_INCLUDED

#include<stdio.h>
#include<stdlib.h>



struct node
{
	int data;
	int nodePosition;
	struct node *left, *right;
};

typedef struct
{
    struct node *root;
    int count;
} TREE;

TREE* createControlStructure(void);
struct node *newNode(int, int );
struct node* insertLeaf(struct node* , int, int );
void printInorder(struct node* );
void printPreorder(struct node* );
void printPostorder(struct node* );
void deleteBTree(struct node* );


#endif // HEADERS_H_INCLUDED
