/* CS2211a 2020 */
/* Lab 09 */
/* ziqin shang */
/* 250890594 */
/* zshang3*/
/*Nov 23 2020 */
#include "headers.h"

TREE* createControlStructure(void)
{
   TREE* BSTree;
   BSTree = (TREE*) malloc (sizeof (TREE));
	if (BSTree)
	   {
              BSTree->root = NULL;
              BSTree->count = 0;
   	   } // if
	return BSTree;
}	// createList

