/* CS2211a 2020 */
/* Lab 09 */
/* ziqin shang */
/* 250890594 */
/* zshang3*/
/*Nov 23 2020 */
#include "headers.h"

void deleteBTree(struct node* node)
{
	if (node == NULL)
		return;
    deleteBTree(node->left);
    deleteBTree(node->right);
	// now deal with the node
	printf("Deleting node: %d data: %d\n", node->nodePosition, node->data);
	free(node);

}
