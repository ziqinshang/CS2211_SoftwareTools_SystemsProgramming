/* CS2211a 2020 */
/* Lab 09 */
/* ziqin shang */
/* 250890594 */
/* zshang3*/
/*Nov 23 2020 */
#include<stdio.h>
#include<stdlib.h>
#include "headers.h"


/* Given a binary tree, print its nodes according to the
"bottom-up" postorder traversal. */
void printPostorder(struct node* node)
{
	if (node == NULL)
		return;

    // first recur on left subtree
    printPostorder(node->left);
    // then recur on right subtree
    printPostorder(node->right);
    // now deal with the node
    printf("position:%d ", node->nodePosition);
    printf("data:%d \n", node->data);
}

/* Given a binary tree, print its nodes in inorder*/
void printInorder(struct node* node)
{
	if (node == NULL)
		return;
    /* first recur on left child */
    printInorder(node->left);
    /* then print the data of node */
    printf("position:%d ", node->nodePosition);
    printf("data:%d \n", node->data);
    /* now recur on right child */
    printInorder(node->right);
}

/* Given a binary tree, print its nodes in preorder*/
void printPreorder(struct node* node)
{
	if (node == NULL)
		return;

    /* first print data of node */
    printf("position:%d ", node->nodePosition);
    printf("data:%d \n", node->data);
    /* then recur on left sutree */
    printPreorder(node->left);
    /* now recur on right subtree */
    printPreorder(node->right);
    
}
