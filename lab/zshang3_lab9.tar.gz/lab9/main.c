/* CS2211a 2020 */
/* Lab 09 */
/* ziqin shang */
/* 250890594 */
/* zshang3*/
/*Nov 23 2020 */
#include "headers.h"

// Driver Program to test BTree functions
int main()
{
	/* Let us create following BST

			70
		  /	 \
		60	 80
		/ \
	  30  50
	  /   /
	 20  40

	  */

	TREE* bTree;

	bTree = createControlStructure();

    int iValues[] = {70,60,30,50,40,80,20};

    struct node *root = bTree->root;

    for (int i = 0; i <=6; i++) {
       root = insertLeaf(root, iValues[i], i);
    }

	printf("\nPreorder traversal of binary tree is \n");
	printPreorder(root);

	printf("\nInorder traversal of binary tree is \n");
	printInorder(root);

	printf("\nPostorder traversal of binary tree is \n");
	printPostorder(root);

	printf("\nFreeing up memory of binary tree: \n");
	deleteBTree(root);

	return 0;

}

