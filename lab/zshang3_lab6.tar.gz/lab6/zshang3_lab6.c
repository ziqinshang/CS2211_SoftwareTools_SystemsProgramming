//cs2211a f20
//ziqin shang
//250890594
//oct 24 2020
int sum_array(const int *a, int size)
{
int sum = 0;
for ( int i = 0; i < size;i++) sum += *(a+i);
return sum;
}
