/* CS2211a 2020 */
/* Lab 09 */
/* ziqin shang */
/* 250890594 */
/* zshang3*/
/*Nov 23 2020 */
#include "headers.h"

// A utility function to create a new BST node
struct node *newNode(int item, int pos)
{
	struct node *temp = (struct node *)malloc(sizeof(struct node));
	temp->data = item;
	temp->nodePosition = pos;
	temp->left = temp->right = NULL;
	return temp;
}

/* A utility function to insert a new node with given data in BST */
struct node* insertLeaf(struct node* node, int data, int pos)
{
	/* If the tree is empty, return a new node */
	if (node == NULL) return newNode(data, pos);

    if (data < node->data)
    node->left = insertLeaf(node->left, data,pos);
    else
    node->right = insertLeaf(node->right, data,pos);

	/* return the (unchanged) node pointer */
	return node;
}


// C function to search a given key in a given BST
struct node* search(struct node* root, int key)
{
    // Base Cases: root is null or key is present at root
    if (root == NULL || root->data == key)
       return root;
     
    // Key is greater than root's key
    if (root->data < key)
       return search(root->right, key);
  
    // Key is smaller than root's key
    return search(root->left, key);
}

/* Given a non-empty binary search tree, return the node with minimum
data value found in that tree. Note that the entire tree does not
need to be searched. */
struct node * minValueNode(struct node* node)
{
struct node* current = node;
/* loop down to find the leftmost leaf */
while (current && current->left != NULL)
current = current->left;
return current;
}

struct node* deleteNode(struct node* root, int data)
{
if (root == NULL) return root;
if (data < root->data)
root->left = deleteNode(root->left, data);
else if (data > root->data)
root->right = deleteNode(root->right, data);
else
{
    if (root->left == NULL)
    {
    struct node *temp = root->right;
    free(root);
    return temp;
    }

else if (root->right == NULL)
    {
    struct node *temp = root->left;
    free(root);
    return temp;
    }

struct node* temp = minValueNode(root->right);
root->data = temp->data;
root->right = deleteNode(root->right, temp->data);
}
return root;
}
