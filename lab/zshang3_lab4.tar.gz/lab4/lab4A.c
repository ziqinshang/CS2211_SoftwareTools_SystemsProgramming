//cs2211a 2020
//lab04 part1
//prof magguilli (ziqinshang
//oct 12th,2020

#include <stdio.h>
#include <stdlib.h>

int main()
{
    char first_name[15] = {'A','N','T','H','O','N','Y','\0'};
    char last_name[15] = "ADVERSE";
    //char string1[6] = "hello";
    char string1 [5] = "hello";
    //char string1 [6];
    char string2 [ ] = "world";
    //char string3[6] = {'h', 'e', 'l', 'l', 'o', '\0'} ;
    char string3[6] = {'h', 'e', 'l', 'l', 'o','!'} ;
    
    printf("%s\n", first_name);
    puts(last_name);
    printf("%s : %s : %s\n",string1,string2,string3);
    
    return 0;
}
