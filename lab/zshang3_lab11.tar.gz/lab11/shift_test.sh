#!/bin/bash
HOST=$1
USERNAME=$2
shift
PASSWORD=$@
echo "Host is $HOST ; Username is $USERNAME ; Password is $PASSWORD"
