//CS2211a 2020
//Assignment 1
//Ziqin Shang
//250890594
//zshang3
//Sep 21th 2020
#include<stdio.h>
int main(){
printf("Hello World!");
return 0;
}

